package Comesana_Cabeza_Jose_Luis_ED05_Tarea.Comesana_Cabeza_Jose_Luis_ED05_Tarea;

/**
 * Mostrar� todos los productos de la campa�a que se haya asignado por el admiinistrativo
 */
public class Tienda {

	public void mostrarComplementos() {
		throw new UnsupportedOperationException();
	}

	public void mostrarZapatos() {
		throw new UnsupportedOperationException();
	}

	public void mostrarBolsos() {
		throw new UnsupportedOperationException();
	}

}