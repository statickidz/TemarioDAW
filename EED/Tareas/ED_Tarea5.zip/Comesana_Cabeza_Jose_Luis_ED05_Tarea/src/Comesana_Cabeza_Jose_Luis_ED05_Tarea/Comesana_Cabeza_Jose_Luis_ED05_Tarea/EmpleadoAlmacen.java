package Comesana_Cabeza_Jose_Luis_ED05_Tarea.Comesana_Cabeza_Jose_Luis_ED05_Tarea;

/**
 * Una vez realizada la venta el empleado de almacén será el encargado de preparar el pedido y empaquetarlo
 */
public class EmpleadoAlmacen {

	private String nombre;

	/**
	 * 
	 * @param nombre
	 */
	public EmpleadoAlmacen(String nombre) {
		throw new UnsupportedOperationException();
	}

	public String getNombre() {
		return this.nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}