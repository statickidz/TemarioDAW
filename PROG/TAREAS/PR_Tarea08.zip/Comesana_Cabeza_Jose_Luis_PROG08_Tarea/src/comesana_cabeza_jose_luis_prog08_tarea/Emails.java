/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package comesana_cabeza_jose_luis_prog08_tarea;

/**
 *
 * @author José Luis
 */
 class Emails implements Comparable<Emails>{
        public String email;
  
        @Override
        public int compareTo(Emails e){
            return email.compareTo(e.email);
        }
    }
