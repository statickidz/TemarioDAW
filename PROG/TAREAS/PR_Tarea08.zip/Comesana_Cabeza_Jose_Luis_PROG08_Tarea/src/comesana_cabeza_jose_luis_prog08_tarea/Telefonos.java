/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package comesana_cabeza_jose_luis_prog08_tarea;

/**
 *
 * @author José Luis
 */
class Telefonos implements Comparable<Telefonos>  {
        public Long tlf;
        public String mas;
        
        @Override
        public int compareTo(Telefonos t){
            return tlf.compareTo(t.tlf);
        }

}
