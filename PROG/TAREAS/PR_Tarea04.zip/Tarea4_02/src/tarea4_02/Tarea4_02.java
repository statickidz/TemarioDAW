package tarea4_02;
import java.io.*;
/**
 *
 * @author José Luis
 * @version 4.2
 */
public class Tarea4_02 {
    static BufferedReader opcion = new BufferedReader(new InputStreamReader(System.in));
    public static void main(String[] args) {
        int op=0;
        while(op<1 || op>3){
            System.out.println("Elige una opción:\n");
            System.out.println("1 - Operaciones básicas");
            System.out.println("2 - Operaciones complejas");
            System.out.println("3 - Salir");
            try{
                op = Integer.parseInt(opcion.readLine());
                if(op<1 || op>3) System.err.println("Sólo valores enteros entre 1 y 3");
            }catch(IOException e){
                System.err.println("Error en la entrada de datos");
            }catch(NumberFormatException e){
                System.err.println("Sólo son válidos valores enteros entre 1 y 3");
            }
            switch(op){
                case 1:
                    basicas.inicio();
                    op=0;
                    break;
                case 2:
                    complejas.inicio();
                    op=0;
                    break;
                case 3:
                    System.out.println("¡Hasta pronto!");
            }
        }
    }
}
