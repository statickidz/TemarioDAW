package cuentasbancarias;

import java.util.ArrayList;
import java.util.Hashtable;

/**
 *
 * @author José Luis
 * @version 9.1
 */
public interface Imprimible {
    ArrayList ContenidoArrayList();
    Hashtable ContenidoHashtable();
}
