package tarea3_04;
import java.io.*;
/**
 * @author José Luis
 * @version 3.4
 */
public class Tarea3_04 {
    static BufferedReader dato = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) throws IOException{
        int opcion=9;
        while(opcion != 0){
            opcion=menu();
            if(opcion==1) operaciones.introDatos();
            if(opcion==2) operaciones.consulDatos();
        }
    }
    static int menu() throws IOException{
        int opcion=9;
        while(opcion<0 || opcion>2){
            System.out.println("  menu de opciones  ");
            System.out.println("--------------------");
            System.out.println("1 - Introducir datos");
            System.out.println("2 - Consultar datos ");
            System.out.println("0 - Salir ");
            System.out.println("--------------------");
            System.out.println("  Qué desea hacer?  ");
            opcion=Integer.parseInt(dato.readLine());
        }
        return opcion;
    }

}
