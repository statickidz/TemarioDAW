package tarea3_01;

/**
 * @author José Luis
 * @version 3.1
 */
public class Persona {
    String nombre;
    int edad;
    float altura;

    String consulta_Nombre(){
        return nombre;
    }

    void cambia_Nombre(String nom){
        nombre=nom;
    }
}
