/**
 *
 * @author José Luis
 * @class enumerado
 * @description crear una variable de tipo enumerado
 */
public class enumerado {
    public enum Meses{Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre};
    public static void main(String args[]){ // Comienza la clase main
        enumerado.Meses m;
        m = Meses.Marzo;
        System.out.println("El valor de la variable 'm' es "+ m);
    } // Cierre de main
    
} // Cierre de la clase
