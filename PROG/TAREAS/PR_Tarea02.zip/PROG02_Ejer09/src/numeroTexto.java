import java.util.Scanner;
/**
 * @author José Luis
 * @class numeroTexto
 * @description Poner un número como texto separando sus cifras
 */

public class numeroTexto {
    public static void main (String args[]){
        Scanner dato=new Scanner (System.in);
        int numero;
        System.out.println("Introduzca un número de cinco cifras: ");
        numero = dato.nextInt();
        while((numero>99999) || (numero<10000)){
            System.out.println("Número erróneo. Sólo 5 cifras. Vuelva a intentarlo: ");
            numero = dato.nextInt();
        }
    
        System.out.println("El número: "+numero+" como texto es "+numTex(numero));
    }
    public static String numTex(int n1){
        int x,y;
        String z="";
        x = n1;
        while(x>0){
            y=x%10;
            x=x/10;
            z=String.valueOf(y)+" "+z;
        }                                             
        return z;
    }
}

