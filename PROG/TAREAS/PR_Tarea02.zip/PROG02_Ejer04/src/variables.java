/**
 *
 * @author José Luis
 * @class variables
 * @description Uso de variables en Java
 */
public class variables { // clase que habrá de ser del mismo nombre que el fichero java
    //public enum Sexo{H,M};
    public static void main(String args[]){ // Comienza la clase principal
        boolean casado;
        final long MAXIMO;
        byte diasem;
        short diaanual;
        long miliseg;
        float totalfactura;
        long poblacion;
        char sexo1;
    //    variables.Sexo sexo;
        casado = true;
        MAXIMO = 999999;
        diasem = 1;
        diaanual = 300;
        miliseg = System.currentTimeMillis();
        totalfactura = 10350.677734F;
        poblacion = 6775235741L;
    //    sexo = Sexo.M;
        sexo1 = 'M';
        // Usando la orden println
        System.out.println("----- EJERCICIO DE VARIABLES Y TIPOS DE DATOS -----");
        System.out.println("El valor de la variable casado es "+casado);
        System.out.println("El valor de la variable MAXIMO es "+MAXIMO);
        System.out.println("El valor de la variable diasem es "+diasem);
        System.out.println("El valor de la variable diaanual es "+diaanual);
        System.out.println("El valor de la variable miliseg es "+miliseg);
        System.out.println("El valor de la variable totalfactura es "+totalfactura);
        System.out.println("El valor de la variable población es "+ poblacion);
        System.out.println("El valor de la variable sexo es "+ sexo1);
        // Usando la orden printf
        System.out.printf("----- EJERCICIO DE VARIABLES Y TIPOS DE DATOS -----");
        System.out.printf("\nEl valor de la variable casado es "+casado);
        System.out.printf("\nEl valor de la variable MAXIMO es "+MAXIMO);
        System.out.printf("\nEl valor de la variable diasem es "+diasem);
        System.out.printf("\nEl valor de la variable diaanual es "+diaanual);
        System.out.printf("\nEl valor de la variable miliseg es "+miliseg);
        System.out.printf("\nEl valor de la variable totalfactura es %.6f",totalfactura);
        System.out.printf("\nEl valor de la variable totalfactura en notación científica es %E",totalfactura);
        System.out.printf("\nEl valor de la variable población es "+ poblacion);
        System.out.printf("\nEl valor de la variable sexo es "+ sexo1+"\n");
        
    } // Cierre de main
    
} // Cierre de la clase
