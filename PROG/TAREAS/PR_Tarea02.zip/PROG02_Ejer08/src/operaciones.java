import java.util.Scanner;
/**
 * @author José Luis
 * @class operaciones
 * @description Realizar varias operaciones aritméticas con dos números introducidos por teclado
 */

public class operaciones {
    public static void main (String args[]){
        Scanner dato = new Scanner( System.in );
        float x,y;
        System.out.println("Introduzca el primer número: ");
        x = dato.nextFloat();
        System.out.println("Introduzca el segundo número: ");
        y = dato.nextFloat();
        System.out.printf("x=%.1f y=%.1f\n",x,y);
        System.out.printf("x + y = %.1f\n",(x+y));
        System.out.printf("x - y = %.1f\n",(x-y));
        System.out.printf("x * y = %.1f\n",(x*y));
        System.out.printf("x / y = %.1f\n",(x/y));
        System.out.printf("x ^ 2 = %.1f\n",(x*x));
        System.out.printf("x raiz 2 = %.1f\n",Math.sqrt(x));
    }
}
