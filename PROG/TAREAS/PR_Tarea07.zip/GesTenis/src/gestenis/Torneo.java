package gestenis;

import java.io.*;
import java.util.ArrayList;

/**
 *
 * @author José Luis Comesaña
 * @version 7.0
 */
public class Torneo implements Serializable {
    public static String GRAND_SLAM = "Grand Slam";
    public static String MASTER1000 = "ATP World Tour Master 1000";
    public static String MASTER500 = "ATP World Tour 500";
    public static String MASTER250 = "ATP World Tour 250";
    
    private String nombre;
    private int puntuacion;
    
    Torneo (String nombre,int puntuacion){
        this.nombre=nombre;
        this.puntuacion=puntuacion;
    }

    /**
     * Devuelve el nombre del torneo
     * @return
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Asignamos un nombre de torneo
     * @param <code>nombre</code> del torneo
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Devuelve la puntuación asignada al torneo
     * @return
     */
    public int getPuntuacion() {
        return puntuacion;
    }

    /**
     * Introducimos la puntuación asignada para el torneo
     * @param
     */
    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }
    /**
     * Carga los datos del <code>fichero</code> en el ArrayList <code>lista</code>
     * y devuelve <code>true</code> si todo ha ido bien o <code>false</code> si ha fallado algo
     * @param <code>fichero</code>
     * @return
     */
    public static ArrayList<Torneo> cargar(File fichero){
        ArrayList<Torneo> lista = null;
        try{
            ObjectInputStream ficheroEntrada = new ObjectInputStream(new FileInputStream(fichero));
            lista = (ArrayList<Torneo>) ficheroEntrada.readObject();
            ficheroEntrada.close();
            return lista;
        }catch(ClassNotFoundException cnfe){
            return null;
        }catch(FileNotFoundException fnfe){
            return null;
        }catch (IOException ioe){
            return null;
        }
    }
    /**
     * Guarda los datos del ArrayList <code>lista</code> en el fichero <code>fichero</code>
     * Si todo ha ido bien devuelve <code>true</code> y en caso contrario <code>false</code> 
     * @param <code>lista</code>
     * @param <code>fichero</code>
     * @return
     */
    public static boolean guardar(ArrayList<Torneo> lista,File fichero){
        try{
            ObjectOutputStream ficheroSalida = new ObjectOutputStream(new FileOutputStream (fichero));
            ficheroSalida.writeObject(lista);
            ficheroSalida.flush();
            ficheroSalida.close();
            return true;
        }catch(FileNotFoundException fnfe){
            return false;
        }catch(IOException ioe){
            return false;
        }
    }
}
